#include "serial.h"
#include "stdint.h"
#include <stdlib.h>
uint8_t data;
uint16_t length = -1;//这一个数据的总长度
uint8_t x = 0;//用于记录目前到第几个位置

void serial_process(UART_HandleTypeDef *huart)
{
    HAL_UART_Receive_IT(huart, &data, sizeof(data));
    data_process(&data);
}

void data_process(uint8_t *data)
{
uint8_t status;
if (x>=0 && x<=4)
{status = 0;}
if (x>=5 && x<=6)
{status = 1;}
if (length > 0)
{status = 2;}
if (length == 0 && x >= 7)
{status = 3;}
	switch (status)
	{
	case 0:
		header(data, &frame_header, *buff);
	break;
	case 1:
		cmd(data, cmd_id);
	break;
	case 2:
		data_rec(data);
	break;
	case 3:
		tail();
	break;
	default:
		reset();
	break;
	}
}

void header (uint8_t* data,frame_header* frame_header, uint8_t *buff)
{
	switch (x)
	{
		case 0:
			frame_header->SOF=*data;
			switch(frame_header->SOF)
			{
			case(0xA5):
			break;
			default:
				reset();
			break;

			}
		break;
		case 1:
			frame_header->data_length |= (uint16_t)*data;
		break;
		case 2:
			frame_header->data_length |= (uint16_t)*data<<8;
			length = frame_header->data_length;
			buff = (uint8_t*)malloc(8 * length * sizeof(uint8_t));
		break;
		case 3:
			frame_header->seq=*data;
		break;
		case 4:
			frame_header->CRC8=*data;
		break;
	}
x++;
}

void cmd(uint8_t *data,uint16_t *cmd_id)
{
	switch (x)
	{
	case 5:
		*cmd_id |= (uint16_t)*data;
	break;
	case 6:
		*cmd_id |= (uint16_t)*data<<8;
	break;
	}
x ++;
}

void data_rec(uint8_t *data,uint8_t *buff)
{
	uint8_t a = x-7;
	if (length > 1)
	{
		buff[a] |= *data;
	}
	if (length == 1)
	{
		buff[a] |= *data;
		read(buff);
		free(buff);
	}
x++;
}

void read (const uint8_t *buff)
{

}

void tail ()
{

}

void reset()
{
	length = -1;
	x = 0;
}
