/*
 * data_class.c
 *
 *  Created on: Apr 15, 2023
 *      Author: 84766
 */
#include "data_class.h"

void data_type(const uint16_t cmd_id)
{
	switch(cmd_id)
	{
	    case 0x0001:
	    	ext_game_status_t struct_ptr = &ext_game_status;
	        break;
	    case 0x0002:

	        break;
	    case 0x0003:

	        break;
	    case 0x0004:

	        break;
	    case 0x0005:

	        break;
	    case 0x0101:

	        break;
	    case 0x0102:

	        break;
	    case 0x0103:

	        break;
	    case 0x0104:

	        break;
	    case 0x0105:

	        break;
	    case 0x0201:

	        break;
	    case 0x0202:

	        break;
	    case 0x0203:

	        break;
	    case 0x0204:

	        break;
	    case 0x0205:

	        break;
	    case 0x0206:

	        break;
	    case 0x0207:

	        break;
	    case 0x0208:

	        break;
	    case 0x0209:

	        break;
	    case 0x020A:

	        break;
	    case 0x0301:

	        break;
	    case 0x0302:

	        break;
	    case 0x0303:

	        break;
	    case 0x0304:

	        break;
	    case 0x0305:

	        break;
	    default:
	        break;
	}
}
