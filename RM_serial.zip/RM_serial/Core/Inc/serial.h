/*
 * serial.h
 *
 *  Created on: 2023年4月15日
 *      Author: 84766
 */

#ifndef INC_SERIAL_H_
#define INC_SERIAL_H_

//#include "main.h"
#include "stdint.h"
#include "data_class.h"
#include <stddef.h>

void data_process();
void header();
void cmd();
void data_rec();
void tail();
void read();
void reset();

typedef __packed struct
{
uint8_t SOF;
uint16_t data_length;
uint8_t seq;
uint8_t CRC8;
uint8_t *buff;
}frame_header;
frame_header frame_header;

uint16_t cmd_id;

uint16_t frame_tail;

#endif /* INC_SERIAL_H_ */
